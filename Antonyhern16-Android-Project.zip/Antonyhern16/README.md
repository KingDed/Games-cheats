# Antonyhern16 — Android training + performance companion

Starter Android project for REDMAGIC 11 Pro with COD Mobile and PUBG Mobile profiles.

## What works in this starter
- Android app with a dark gaming-style dashboard.
- COD Mobile / PUBG Mobile profile selection saved locally.
- Local ON/OFF preference switches saved with Android SharedPreferences.
- Adjustable sensitivity and target-size *notes* saved locally; these do not alter game settings.
- Built-in tap-target practice drill with score and accuracy.
- Performance checklist with persistent local checkboxes.

## Important limits
This companion does not inject input into games, change game files, bypass anti-cheat, control game recoil, provide an aimbot, or modify COD Mobile / PUBG Mobile aim-assist. Android apps cannot universally change another app's private settings. Performance checklist items are reminders, not privileged system controls.

## Build a debug APK on GitHub using only your phone
1. Sign in to GitHub and create a new repository named `Antonyhern16`.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository root. Keep `.github/workflows/android.yml` in place.
3. Open **Actions** in the repository, choose **Build Antonyhern16 APK**, and press **Run workflow**. The first build may also run automatically after a push.
4. When the run finishes, open it and download the `Antonyhern16-debug-apk` artifact. Unzip the artifact to get the APK.
5. On your REDMAGIC phone, open the APK. If Android asks, allow your browser or file manager to install unknown apps, then install it.

The debug APK is signed with Android's debug key and is suitable for testing. It is not a Play Store release signing key.

## Create a persistent release signing key (optional)
Do this on a trusted computer with Android build tools or OpenSSL/keytool installed. Keep the keystore and passwords private and backed up. Never commit them to GitHub.

Generate a keystore:
```bash
keytool -genkeypair -v -keystore antonyhern16-release.jks -alias antonyhern16 -keyalg RSA -keysize 2048 -validity 10000
```
Base64-encode the keystore as one line:
```bash
base64 -w 0 antonyhern16-release.jks
```
On GitHub, open **Settings → Secrets and variables → Actions → New repository secret** and add:
- `ANDROID_KEYSTORE_BASE64` = the one-line Base64 output
- `ANDROID_STORE_PASSWORD` = keystore password
- `ANDROID_KEY_ALIAS` = `antonyhern16`
- `ANDROID_KEY_PASSWORD` = key password

Run the workflow again. It will upload `Antonyhern16-signed-release-apk` when those secrets are configured. Do not lose the keystore: future updates must be signed with the same key to update the installed app normally.

## Build locally
Install Android Studio, JDK 17, Android SDK Platform 35, and Gradle 8.9. From the project root run:
```bash
gradle assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Package ID
`com.antonyhern16.companion`
