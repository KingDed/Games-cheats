package com.antonyhern16.companion;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout page;
    private String selectedGame = "COD Mobile";
    private int hits = 0, attempts = 0;
    private TextView stats;
    private int red = Color.rgb(235, 55, 65);
    private int dark = Color.rgb(18, 20, 26);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("antonyhern16", MODE_PRIVATE);
        getWindow().setStatusBarColor(dark);
        getWindow().setNavigationBarColor(dark);
        showHome();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, 5, 0, 5); return t;
    }
    private void setup(String title) {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(dark);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(20, 24, 20, 28);
        scroll.addView(page); setContentView(scroll);
        TextView brand = text("ANTONYHERN16", 24, Color.WHITE); brand.setTypeface(null, Typeface.BOLD); page.addView(brand);
        TextView sub = text(title, 14, red); page.addView(sub);
        View line = new View(this); line.setBackgroundColor(red); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 2); lp.setMargins(0, 12, 0, 18); page.addView(line, lp);
    }
    private void section(String title) {
        TextView t = text(title, 17, Color.WHITE); t.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 14, 0, 6); page.addView(t, p);
    }
    private void button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(bg(Color.rgb(48, 50, 60), 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 5, 0, 5); page.addView(b, p); b.setOnClickListener(v -> action.run());
    }
    private void toggle(String key, String label, boolean defaultValue, String note) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(label, 15, Color.WHITE)); if (note != null) left.addView(text(note, 11, Color.LTGRAY));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this); sw.setButtonTintList(null); sw.setChecked(prefs.getBoolean(key, defaultValue));
        sw.setOnCheckedChangeListener((v, checked) -> prefs.edit().putBoolean(key, checked).apply()); row.addView(sw);
        row.setPadding(0, 8, 0, 8); page.addView(row);
    }
    private void showHome() {
        setup("TRAINING  •  PERFORMANCE  •  PROFILES");
        TextView intro = text("A local companion for REDMAGIC 11 Pro. Settings are saved on this device; game controls are not injected into games.", 14, Color.LTGRAY);
        page.addView(intro);
        section("GAME PROFILE");
        String[] games = {"COD Mobile", "PUBG Mobile"};
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, games));
        selectedGame = prefs.getString("game", "COD Mobile");
        spinner.setSelection(selectedGame.equals("PUBG Mobile") ? 1 : 0);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                selectedGame = games[pos]; prefs.edit().putString("game", selectedGame).apply();
            }
        });
        page.addView(spinner);
        section("LOCAL COMPANION CONTROLS");
        toggle("training_reminders", "Aim training reminders", true, "A local preference for your practice routine");
        toggle("show_stats", "Show practice statistics", true, "Tracks taps only inside this app");
        toggle("performance_notes", "Performance checklist", true, "Displays optimization tips; does not change system performance modes");
        toggle("haptics", "Practice haptic feedback", false, "Saved preference; vibration behavior is not enabled in this starter build");
        section("SENSITIVITY NOTES");
        TextView note = text("Use these as personal notes, not game-level controls. Changes here do not modify COD Mobile or PUBG Mobile settings.", 13, Color.LTGRAY);
        page.addView(note);
        addSlider("Look sensitivity note", "look_sens", 100, 1, 200);
        addSlider("ADS sensitivity note", "ads_sens", 90, 1, 200);
        addSlider("Practice target size", "target_size", 55, 25, 100);
        button("OPEN AIM TRAINING", this::showTraining);
        button("PERFORMANCE CHECKLIST", this::showPerformance);
        button("RESET LOCAL SETTINGS", () -> { prefs.edit().clear().apply(); showHome(); });
        page.addView(text("No aimbot, recoil manipulation, touch injection, or online-game modification.", 11, Color.LTGRAY));
    }
    private void addSlider(String label, String key, int def, int min, int max) {
        section(label);
        TextView value = text("", 13, Color.LTGRAY); page.addView(value);
        SeekBar seek = new SeekBar(this); seek.setMax(max-min); seek.setProgress(prefs.getInt(key, def)-min);
        value.setText(String.format(Locale.US, "Saved value: %d", seek.getProgress()+min));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) { value.setText(String.format(Locale.US, "Saved value: %d", p+min)); if(user) prefs.edit().putInt(key,p+min).apply(); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        page.addView(seek);
    }
    private void showPerformance() {
        setup("PERFORMANCE CHECKLIST");
        section("BEFORE A MATCH");
        page.addView(text("These are recommendations, not system-level switches. Apply supported options in REDMAGIC Game Space or Android settings yourself.", 14, Color.LTGRAY));
        toggle("tip_refresh", "Check refresh-rate setting", true, "Use a rate supported by the game and display");
        toggle("tip_battery", "Avoid battery saver while gaming", true, "Higher performance can increase heat and battery use");
        toggle("tip_network", "Prefer stable low-latency network", true, "Use a reliable Wi-Fi connection or strong mobile signal");
        toggle("tip_temp", "Pause if the phone gets too hot", true, "Thermal throttling can reduce sustained performance");
        toggle("tip_apps", "Close unnecessary background apps", false, "May free resources, but gains vary");
        button("BACK TO HOME", this::showHome);
    }
    private void showTraining() {
        setup("AIM TRAINING");
        page.addView(text("Tap the targets that appear in this practice area. This mini-drill runs only inside Antonyhern16 and does not interact with other games.", 13, Color.LTGRAY));
        stats = text("", 18, Color.WHITE); page.addView(stats); updateStats();
        FrameLayout arena = new FrameLayout(this); arena.setBackground(bg(Color.rgb(30, 33, 42), 20));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, 470); ap.setMargins(0, 12, 0, 12); page.addView(arena, ap);
        TextView target = new TextView(this); target.setText("＋"); target.setTextColor(Color.WHITE); target.setTextSize(30); target.setGravity(Gravity.CENTER);
        int size = prefs.getInt("target_size",55);
        target.setBackground(bg(red, 100)); FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(size*2, size*2);
        tp.leftMargin = 30; tp.topMargin = 35; arena.addView(target,tp);
        target.setOnClickListener(v -> {
            hits++; attempts++; updateStats(); target.setText("✓");
            target.postDelayed(() -> {
                int w = Math.max(1, arena.getWidth()-target.getWidth()); int h = Math.max(1, arena.getHeight()-target.getHeight());
                FrameLayout.LayoutParams np = (FrameLayout.LayoutParams)target.getLayoutParams();
                np.leftMargin = (int)(Math.random()*w); np.topMargin = (int)(Math.random()*h); target.setLayoutParams(np); target.setText("＋");
            }, 160);
        });
        arena.setOnClickListener(v -> { attempts++; updateStats(); });
        button("RESET SCORE", () -> { hits=0; attempts=0; updateStats(); });
        button("BACK TO HOME", this::showHome);
    }
    private void updateStats() {
        if (stats != null) stats.setText("Hits: " + hits + "   Attempts: " + attempts + "   Accuracy: " + (attempts == 0 ? 0 : Math.round(100f*hits/attempts)) + "%");
    }
}
